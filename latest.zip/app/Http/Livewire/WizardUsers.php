<?php

namespace App\Http\Livewire;

use Livewire\Component;

class WizardUsers extends Component
{
    public function render()
    {
        return view('livewire.wizard-users');
    }
}
